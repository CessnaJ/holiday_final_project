# 초기 데이터 생성을 위한 파일

import json
import requests
from secret import TMDB_API_KEY
# git ignore처리함.


tmdb_url = f'https://api.themoviedb.org/3/genre/movie/list?api_key={TMDB_API_KEY}&language=ko'

result = requests.get(tmdb_url).json()
data = result['genres']
print(result)

genres = []

for genre in data:
    genre = {
        'model': 'movies.genre',
        'pk': genre.get('id'),
        'fields': {
			'name': genre.get('name'),
        },
    }
    genres.append(genre)
'''
{'genres': 
	[
        {'id': 28, 'name': '액션'}, 
    	{'id': 12, 'name': '모험'}, 
        {'id': 16, 'name': '애니메이션'}, 
        {'id': 35, 'name': '코미디'}, 
        {'id': 80, 'name': '범죄'}, 
        {'id': 99, 'name': '다큐멘터리'}, 
        {'id': 18, 'name': '드라마'}, 
        {'id': 10751, 'name': '가족'}, 
        {'id': 14, 'name': '판타지'}, 
        {'id': 36, 'name': '역사'}, 
		{'id': 27, 'name': '공포'}, 
        {'id': 10402, 'name': '음악'}, 
        {'id': 9648, 'name': '미스터리'}, 
        {'id': 10749, 'name': '로맨스'}, 
        {'id': 878, 'name': 'SF'}, 
        {'id': 10770, 'name': 'TV 영화'}, 
        {'id': 53, 'name': '스릴러'}, 
        {'id': 10752, 'name': '전쟁'}, 
        {'id': 37, 'name': '서부'}
	]
}
'''
with open('genredata.json', 'w', encoding='utf-8') as file:
    json.dump(genres, file, ensure_ascii=False)
    # ensure_ascii=False로 해야 한글이 출력됨. 안그러면 아스키코드로 변환해버림